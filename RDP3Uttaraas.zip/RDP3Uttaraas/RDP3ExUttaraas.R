install.packages("streamR", "RCurl", "ROAuth", "RJSONIO", "ggplot2", "plotrix", "plyr", "RColorBrewer")
library(streamR)
library(RCurl)
library(RJSONIO)
library(stringr)
library(ggplot2)
library(plotrix)
library(RColorBrewer)

require(gdata)
#change the path for different boroughs. Please do not change variable names
bk <- read.xls("C:\\Users\\UT\\Documents\\EDAAA\\Prob3\\rollingsales_brooklyn.xls",pattern="BOROUGH")
bronx <- read.xls("C:\\Users\\UT\\Documents\\EDAAA\\Prob3\\rollingsales_bronx.xls",pattern="BOROUGH")
manh <- read.xls("C:\\Users\\UT\\Documents\\EDAAA\\Prob3\\rollingsales_manhattan.xls",pattern="BOROUGH")
quee <- read.xls("C:\\Users\\UT\\Documents\\EDAAA\\Prob3\\rollingsales_queens.xls",pattern="BOROUGH")
sisland<- read.xls("C:\\Users\\UT\\Documents\\EDAAA\\Prob3\\rollingsales_statenisland.xls",pattern="BOROUGH")




head(bk)
summary(bk)
bk$SALE.PRICE.N <- as.numeric(gsub("[^[:digit:]]","",bk$SALE.PRICE))
count(is.na(bk$SALE.PRICE.N))
names(bk) <- tolower(names(bk))

## clean/format the data with regular expressions
bk$gross.sqft <- as.numeric(gsub("[^[:digit:]]","",bk$gross.square.feet))
bk$land.sqft <- as.numeric(gsub("[^[:digit:]]","",bk$land.square.feet))
bk$sale.date <- as.Date(bk$sale.date)
bk$year.built <- as.numeric(as.character(bk$year.built))
## do a bit of exploration to make sure there's not anything
## weird going on with sale prices
attach(bk)
hist(sale.price.n)
hist(sale.price.n[sale.price.n>0])
hist(gross.sqft[sale.price.n==0])
detach(bk)
## keep only the actual sales
bk.sale <- bk[bk$sale.price.n!=0,]
#plot(bk.sale$gross.sqft,(bk.sale$sale.price.n))
#plot(log(bk.sale$gross.sqft),(bk.sale$sale.price.n))

area <- aggregate(bk$sale.price.n,by=list(Category=bk$neighborhood),FUN=sum)
colnames(area) <- c("Neighborhood","Total.Sales")
library(plyr)
area <- arrange(area,desc(Total.Sales))
#ggplot(head(area,8),aes(x=Neighborhood,y=(Total.Sales),fill=Neighborhood)) + geom_bar(stat="identity")
#ggplot(tail(area,5),aes(x=Neighborhood,y=Total.Sales,fill=Neighborhood)) + geom_bar(stat="identity")


## for now, let's look at 1-, 2-, and 3-family homes
bk.homes <- bk.sale[which(grepl("FAMILY",bk.sale$building.class.category)),]
#plot((bk.homes$gross.sqft),log(bk.homes$sale.price.n))
bk.homes[which(bk.homes$sale.price.n<100000),][order(bk.homes[which(bk.homes$sale.price.n<100000),]$sale.price.n),]
## remove outliers that seem like they weren't actual sales
bk.homes$outliers <- (log(bk.homes$sale.price.n) <=5) + 0
bk.homes <- bk.homes[which(bk.homes$outliers==0),]
#plot(log(bk.homes$gross.sqft),log(bk.homes$sale.price.n))


area <- aggregate(bk$sale.price.n,by=list(Category=bk$neighborhood),FUN=max)
colnames(area) <- c("Neighborhood","Biggest.Sale")
area <- arrange(area,desc(Biggest.Sale))
#ggplot(head(area,5),aes(x=Neighborhood,y=log(Biggest.Sale),fill=Neighborhood)) + geom_bar(stat="identity")
#ggplot(tail(area,5),aes(x=Neighborhood,y=Biggest.Sale,fill=Neighborhood)) + geom_bar(binwidth=10)


bk$year<-gsub(".*(\\d{4})-(\\d{2}).*","\\1-\\2",bk$sale.date)
yearly <- aggregate(bk$sale.price.n,by=list(Category=bk$year),FUN=sum)
colnames(yearly) <- c("Year.Month", "Sales")
ggplot(yearly,aes(x=Year.Month,y=(Sales),fill=Year.Month)) + geom_bar(stat="identity")


filterbk <- bk[bk$land.sqft>0,]
filterbk <- filterbk[filterbk$gross.sqft>0,]
byland <- aggregate(filterbk$land.sqft,by=list(Category=filterbk$year),FUN=sum)


area <- aggregate(filterbk$land.sqft,by=list(Category=filterbk$neighborhood),FUN=sum)
colnames(area) <- c("Neighborhood", "Land.Sq.Ft")
area <- arrange(area,desc(Land.Sq.Ft))
#ggplot(head(area,10),aes(x=Neighborhood,y=Land.Sq.Ft,fill=Neighborhood)) + geom_bar(stat = "identity")

############manhattan


head(manh)
summary(manh)
manh$SALE.PRICE.N <- as.numeric(gsub("[^[:digit:]]","",manh$SALE.PRICE))
count(is.na(manh$SALE.PRICE.N))
names(manh) <- tolower(names(manh))

## clean/format the data with regular expressions
manh$gross.sqft <- as.numeric(gsub("[^[:digit:]]","",manh$gross.square.feet))
manh$land.sqft <- as.numeric(gsub("[^[:digit:]]","",manh$land.square.feet))
manh$sale.date <- as.Date(manh$sale.date)
manh$year.built <- as.numeric(as.character(manh$year.built))
## do a bit of exploration to make sure there's not anything
## weird going on with sale prices
attach(manh)
hist(sale.price.n)
hist(sale.price.n[sale.price.n>0])
hist(gross.sqft[sale.price.n==0])
detach(manh)
## keep only the actual sales
manh.sale <- manh[manh$sale.price.n!=0,]
#plot(manh.sale$gross.sqft,(manh.sale$sale.price.n))
#plot(log(manh.sale$gross.sqft),(manh.sale$sale.price.n))

area <- aggregate(manh$sale.price.n,by=list(Category=manh$neighborhood),FUN=sum)
colnames(area) <- c("Neighborhood","Total.Sales")
library(plyr)
area <- arrange(area,desc(Total.Sales))
#ggplot(head(area,8),aes(x=Neighborhood,y=(Total.Sales),fill=Neighborhood)) + geom_bar(stat="identity")
#ggplot(tail(area,5),aes(x=Neighborhood,y=Total.Sales,fill=Neighborhood)) + geom_bar(stat="identity")


## for now, let's look at 1-, 2-, and 3-family homes
manh.homes <- manh.sale[which(grepl("FAMILY",manh.sale$building.class.category)),]
#plot((manh.homes$gross.sqft),log(manh.homes$sale.price.n))
manh.homes[which(manh.homes$sale.price.n<100000),][order(manh.homes[which(manh.homes$sale.price.n<100000),]$sale.price.n),]
## remove outliers that seem like they weren't actual sales
manh.homes$outliers <- (log(manh.homes$sale.price.n) <=5) + 0
manh.homes <- manh.homes[which(manh.homes$outliers==0),]
#plot(log(manh.homes$gross.sqft),log(manh.homes$sale.price.n))


area <- aggregate(manh$sale.price.n,by=list(Category=manh$neighborhood),FUN=max)
colnames(area) <- c("Neighborhood","Biggest.Sale")
area <- arrange(area,desc(Biggest.Sale))
#ggplot(head(area,5),aes(x=Neighborhood,y=log(Biggest.Sale),fill=Neighborhood)) + geom_bar(stat="identity")
#ggplot(tail(area,5),aes(x=Neighborhood,y=Biggest.Sale,fill=Neighborhood)) + geom_bar(binwidth=10)


manh$year<-gsub(".*(\\d{4})-(\\d{2}).*","\\1-\\2",manh$sale.date)
yearly <- aggregate(manh$sale.price.n,by=list(Category=manh$year),FUN=sum)
colnames(yearly) <- c("Year.Month", "Sales")
ggplot(yearly,aes(x=Year.Month,y=(Sales),fill=Year.Month)) + geom_bar(stat="identity")


filtermanh <- manh[manh$land.sqft>0,]
filtermanh <- filtermanh[filtermanh$gross.sqft>0,]
byland <- aggregate(filtermanh$land.sqft,by=list(Category=filtermanh$year),FUN=sum)


area <- aggregate(filtermanh$land.sqft,by=list(Category=filtermanh$neighborhood),FUN=sum)
colnames(area) <- c("Neighborhood", "Land.Sq.Ft")
area <- arrange(area,desc(Land.Sq.Ft))
ggplot(head(area,10),aes(x=Neighborhood,y=Land.Sq.Ft,fill=Neighborhood)) + geom_bar(stat = "identity")

##########################queen



head(quee)
summary(quee)
quee$SALE.PRICE.N <- as.numeric(gsub("[^[:digit:]]","",quee$SALE.PRICE))
count(is.na(quee$SALE.PRICE.N))
names(quee) <- tolower(names(quee))

## clean/format the data with regular expressions
quee$gross.sqft <- as.numeric(gsub("[^[:digit:]]","",quee$gross.square.feet))
quee$land.sqft <- as.numeric(gsub("[^[:digit:]]","",quee$land.square.feet))
quee$sale.date <- as.Date(quee$sale.date)
quee$year.built <- as.numeric(as.character(quee$year.built))
## do a bit of exploration to make sure there's not anything
## weird going on with sale prices
attach(quee)
hist(sale.price.n)
hist(sale.price.n[sale.price.n>0])
hist(gross.sqft[sale.price.n==0])
detach(quee)
## keep only the actual sales
quee.sale <- quee[quee$sale.price.n!=0,]
#plot(quee.sale$gross.sqft,(quee.sale$sale.price.n))
#plot(log(quee.sale$gross.sqft),(quee.sale$sale.price.n))

area <- aggregate(quee$sale.price.n,by=list(Category=quee$neighborhood),FUN=sum)
colnames(area) <- c("Neighborhood","Total.Sales")
library(plyr)
area <- arrange(area,desc(Total.Sales))
#ggplot(head(area,8),aes(x=Neighborhood,y=(Total.Sales),fill=Neighborhood)) + geom_bar(stat="identity")
#ggplot(tail(area,5),aes(x=Neighborhood,y=Total.Sales,fill=Neighborhood)) + geom_bar(stat="identity")


## for now, let's look at 1-, 2-, and 3-family homes
quee.homes <- quee.sale[which(grepl("FAMILY",quee.sale$building.class.category)),]
#plot((quee.homes$gross.sqft),log(quee.homes$sale.price.n))
quee.homes[which(quee.homes$sale.price.n<100000),][order(quee.homes[which(quee.homes$sale.price.n<100000),]$sale.price.n),]
## remove outliers that seem like they weren't actual sales
quee.homes$outliers <- (log(quee.homes$sale.price.n) <=5) + 0
quee.homes <- quee.homes[which(quee.homes$outliers==0),]
#plot(log(quee.homes$gross.sqft),log(quee.homes$sale.price.n))


area <- aggregate(quee$sale.price.n,by=list(Category=quee$neighborhood),FUN=max)
colnames(area) <- c("Neighborhood","Biggest.Sale")
area <- arrange(area,desc(Biggest.Sale))
#ggplot(head(area,5),aes(x=Neighborhood,y=log(Biggest.Sale),fill=Neighborhood)) + geom_bar(stat="identity")
#ggplot(tail(area,5),aes(x=Neighborhood,y=Biggest.Sale,fill=Neighborhood)) + geom_bar(binwidth=10)


quee$year<-gsub(".*(\\d{4})-(\\d{2}).*","\\1-\\2",quee$sale.date)
yearly <- aggregate(quee$sale.price.n,by=list(Category=quee$year),FUN=sum)
colnames(yearly) <- c("Year.Month", "Sales")
ggplot(yearly,aes(x=Year.Month,y=(Sales),fill=Year.Month)) + geom_bar(stat="identity")


filterquee <- quee[quee$land.sqft>0,]
filterquee <- filterquee[filterquee$gross.sqft>0,]
byland <- aggregate(filterquee$land.sqft,by=list(Category=filterquee$year),FUN=sum)


area <- aggregate(filterquee$land.sqft,by=list(Category=filterquee$neighborhood),FUN=sum)
colnames(area) <- c("Neighborhood", "Land.Sq.Ft")
area <- arrange(area,desc(Land.Sq.Ft))
#ggplot(head(area,10),aes(x=Neighborhood,y=Land.Sq.Ft,fill=Neighborhood)) + geom_bar(stat = "identity")

###################3bronx

head(bronx)
summary(bronx)
bronx$SALE.PRICE.N <- as.numeric(gsub("[^[:digit:]]","",bronx$SALE.PRICE))
count(is.na(bronx$SALE.PRICE.N))
names(bronx) <- tolower(names(bronx))

## clean/format the data with regular expressions
bronx$gross.sqft <- as.numeric(gsub("[^[:digit:]]","",bronx$gross.square.feet))
bronx$land.sqft <- as.numeric(gsub("[^[:digit:]]","",bronx$land.square.feet))
bronx$sale.date <- as.Date(bronx$sale.date)
bronx$year.built <- as.numeric(as.character(bronx$year.built))
## do a bit of exploration to make sure there's not anything
## weird going on with sale prices
attach(bronx)
hist(sale.price.n)
hist(sale.price.n[sale.price.n>0])
hist(gross.sqft[sale.price.n==0])
detach(bronx)
## keep only the actual sales
bronx.sale <- bronx[bronx$sale.price.n!=0,]
#plot(bronx.sale$gross.sqft,(bronx.sale$sale.price.n))
#plot(log(bronx.sale$gross.sqft),(bronx.sale$sale.price.n))

area <- aggregate(bronx$sale.price.n,by=list(Category=bronx$neighborhood),FUN=sum)
colnames(area) <- c("Neighborhood","Total.Sales")
library(plyr)
area <- arrange(area,desc(Total.Sales))
#ggplot(head(area,8),aes(x=Neighborhood,y=(Total.Sales),fill=Neighborhood)) + geom_bar(stat="identity")
#ggplot(tail(area,5),aes(x=Neighborhood,y=Total.Sales,fill=Neighborhood)) + geom_bar(stat="identity")


## for now, let's look at 1-, 2-, and 3-family homes
bronx.homes <- bronx.sale[which(grepl("FAMILY",bronx.sale$building.class.category)),]
#plot((bronx.homes$gross.sqft),log(bronx.homes$sale.price.n))
bronx.homes[which(bronx.homes$sale.price.n<100000),][order(bronx.homes[which(bronx.homes$sale.price.n<100000),]$sale.price.n),]
## remove outliers that seem like they weren't actual sales
bronx.homes$outliers <- (log(bronx.homes$sale.price.n) <=5) + 0
bronx.homes <- bronx.homes[which(bronx.homes$outliers==0),]
#plot(log(bronx.homes$gross.sqft),log(bronx.homes$sale.price.n))


area <- aggregate(bronx$sale.price.n,by=list(Category=bronx$neighborhood),FUN=max)
colnames(area) <- c("Neighborhood","Biggest.Sale")
area <- arrange(area,desc(Biggest.Sale))
#ggplot(head(area,5),aes(x=Neighborhood,y=log(Biggest.Sale),fill=Neighborhood)) + geom_bar(stat="identity")
#ggplot(tail(area,5),aes(x=Neighborhood,y=Biggest.Sale,fill=Neighborhood)) + geom_bar(binwidth=10)


bronx$year<-gsub(".*(\\d{4})-(\\d{2}).*","\\1-\\2",bronx$sale.date)
yearly <- aggregate(bronx$sale.price.n,by=list(Category=bronx$year),FUN=sum)
colnames(yearly) <- c("Year.Month", "Sales")
ggplot(yearly,aes(x=Year.Month,y=(Sales),fill=Year.Month)) + geom_bar(stat="identity")


filterbronx <- bronx[bronx$land.sqft>0,]
filterbronx <- filterbronx[filterbronx$gross.sqft>0,]
byland <- aggregate(filterbronx$land.sqft,by=list(Category=filterbronx$year),FUN=sum)


area <- aggregate(filterbronx$land.sqft,by=list(Category=filterbronx$neighborhood),FUN=sum)
colnames(area) <- c("Neighborhood", "Land.Sq.Ft")
area <- arrange(area,desc(Land.Sq.Ft))
#ggplot(head(area,10),aes(x=Neighborhood,y=Land.Sq.Ft,fill=Neighborhood)) + geom_bar(stat = "identity")




########################staten island

head(sisland)
summary(sisland)
sisland$SALE.PRICE.N <- as.numeric(gsub("[^[:digit:]]","",sisland$SALE.PRICE))
count(is.na(sisland$SALE.PRICE.N))
names(sisland) <- tolower(names(sisland))

## clean/format the data with regular expressions
sisland$gross.sqft <- as.numeric(gsub("[^[:digit:]]","",sisland$gross.square.feet))
sisland$land.sqft <- as.numeric(gsub("[^[:digit:]]","",sisland$land.square.feet))
sisland$sale.date <- as.Date(sisland$sale.date)
sisland$year.built <- as.numeric(as.character(sisland$year.built))
## do a bit of exploration to make sure there's not anything
## weird going on with sale prices
attach(sisland)
hist(sale.price.n)
hist(sale.price.n[sale.price.n>0])
hist(gross.sqft[sale.price.n==0])
detach(sisland)
## keep only the actual sales
sisland.sale <- sisland[sisland$sale.price.n!=0,]
#plot(sisland.sale$gross.sqft,(sisland.sale$sale.price.n))
#plot(log(sisland.sale$gross.sqft),(sisland.sale$sale.price.n))

area <- aggregate(sisland$sale.price.n,by=list(Category=sisland$neighborhood),FUN=sum)
colnames(area) <- c("Neighborhood","Total.Sales")
library(plyr)
area <- arrange(area,desc(Total.Sales))
#ggplot(head(area,8),aes(x=Neighborhood,y=(Total.Sales),fill=Neighborhood)) + geom_bar(stat="identity")
#ggplot(tail(area,5),aes(x=Neighborhood,y=Total.Sales,fill=Neighborhood)) + geom_bar(stat="identity")


## for now, let's look at 1-, 2-, and 3-family homes
sisland.homes <- sisland.sale[which(grepl("FAMILY",sisland.sale$building.class.category)),]
#plot((sisland.homes$gross.sqft),log(sisland.homes$sale.price.n))
sisland.homes[which(sisland.homes$sale.price.n<100000),][order(sisland.homes[which(sisland.homes$sale.price.n<100000),]$sale.price.n),]
## remove outliers that seem like they weren't actual sales
sisland.homes$outliers <- (log(sisland.homes$sale.price.n) <=5) + 0
sisland.homes <- sisland.homes[which(sisland.homes$outliers==0),]
#plot(log(sisland.homes$gross.sqft),log(sisland.homes$sale.price.n))


area <- aggregate(sisland$sale.price.n,by=list(Category=sisland$neighborhood),FUN=max)
colnames(area) <- c("Neighborhood","Biggest.Sale")
area <- arrange(area,desc(Biggest.Sale))
#ggplot(head(area,5),aes(x=Neighborhood,y=log(Biggest.Sale),fill=Neighborhood)) + geom_bar(stat="identity")
#ggplot(tail(area,5),aes(x=Neighborhood,y=Biggest.Sale,fill=Neighborhood)) + geom_bar(binwidth=10)


sisland$year<-gsub(".*(\\d{4})-(\\d{2}).*","\\1-\\2",sisland$sale.date)
yearly <- aggregate(sisland$sale.price.n,by=list(Category=sisland$year),FUN=sum)
colnames(yearly) <- c("Year.Month", "Sales")
ggplot(yearly,aes(x=Year.Month,y=(Sales),fill=Year.Month)) + geom_bar(stat="identity")


filtersisland <- sisland[sisland$land.sqft>0,]
filtersisland <- filtersisland[filtersisland$gross.sqft>0,]
byland <- aggregate(filtersisland$land.sqft,by=list(Category=filtersisland$year),FUN=sum)


area <- aggregate(filtersisland$land.sqft,by=list(Category=filtersisland$neighborhood),FUN=sum)
colnames(area) <- c("Neighborhood", "Land.Sq.Ft")
area <- arrange(area,desc(Land.Sq.Ft))
ggplot(head(area,10),aes(x=Neighborhood,y=Land.Sq.Ft,fill=Neighborhood)) + geom_bar(stat = "identity")





##pie charts 

#borough1--manhattan
manh$sale.date <- as.Date(manh$sale.date)
c113<-sum(manh$commercial.units[cyear<-as.numeric(format(as.Date(manh$sale.date,'%Y-%m-%d'),'%Y'))==2013])
r113<-sum(manh$residential.units[cyear<-as.numeric(format(as.Date(manh$sale.date,'%Y-%m-%d'),'%Y'))==2013])

c112<-sum(manh$commercial.units[cyear<-as.numeric(format(as.Date(manh$sale.date,'%Y-%m-%d'),'%Y'))==2012])
r112<-sum(manh$residential.units[cyear<-as.numeric(format(as.Date(manh$sale.date,'%Y-%m-%d'),'%Y'))==2012])

#borough2--brooklyn
bk$sale.date <- as.Date(bk$sale.date)
c213<-sum(bk$commercial.units[cyear<-as.numeric(format(as.Date(bk$sale.date,'%Y-%m-%d'),'%Y'))==2013])
r213<-sum(bk$residential.units[cyear<-as.numeric(format(as.Date(bk$sale.date,'%Y-%m-%d'),'%Y'))==2013])

c212<-sum(bk$commercial.units[cyear<-as.numeric(format(as.Date(bk$sale.date,'%Y-%m-%d'),'%Y'))==2012])
r212<-sum(bk$residential.units[cyear<-as.numeric(format(as.Date(bk$sale.date,'%Y-%m-%d'),'%Y'))==2012])

#borough3--bronx
bronx$sale.date <- as.Date(bronx$sale.date)
c313<-sum(bronx$commercial.units[cyear<-as.numeric(format(as.Date(bronx$sale.date,'%Y-%m-%d'),'%Y'))==2013])
r313<-sum(bronx$residential.units[cyear<-as.numeric(format(as.Date(bronx$sale.date,'%Y-%m-%d'),'%Y'))==2013])

c312<-sum(bronx$commercial.units[cyear<-as.numeric(format(as.Date(bronx$sale.date,'%Y-%m-%d'),'%Y'))==2012])
r312<-sum(bronx$residential.units[cyear<-as.numeric(format(as.Date(bronx$sale.date,'%Y-%m-%d'),'%Y'))==2012])

#borough4--queens
quee$sale.date <- as.Date(quee$sale.date)
c413<-sum(quee$commercial.units[cyear<-as.numeric(format(as.Date(quee$sale.date,'%Y-%m-%d'),'%Y'))==2013])
r413<-sum(quee$residential.units[cyear<-as.numeric(format(as.Date(quee$sale.date,'%Y-%m-%d'),'%Y'))==2013])

c412<-sum(quee$commercial.units[cyear<-as.numeric(format(as.Date(quee$sale.date,'%Y-%m-%d'),'%Y'))==2012])
r412<-sum(quee$residential.units[cyear<-as.numeric(format(as.Date(quee$sale.date,'%Y-%m-%d'),'%Y'))==2012])

#borough5--staten island
sisland$sale.date <- as.Date(sisland$sale.date)
c513<-sum(sisland$commercial.units[cyear<-as.numeric(format(as.Date(sisland$sale.date,'%Y-%m-%d'),'%Y'))==2013])
r513<-sum(sisland$residential.units[cyear<-as.numeric(format(as.Date(sisland$sale.date,'%Y-%m-%d'),'%Y'))==2013])

c512<-sum(sisland$commercial.units[cyear<-as.numeric(format(as.Date(sisland$sale.date,'%Y-%m-%d'),'%Y'))==2012])
r512<-sum(sisland$residential.units[cyear<-as.numeric(format(as.Date(sisland$sale.date,'%Y-%m-%d'),'%Y'))==2012])


#### please make sure correct names are mapped in columns against their respective r and c values from above
library("plotrix")
slices <- c(r112,r212,r312,r412,r512)
lbls <- c("Manhattan", "Brooklyn", "Bronx", "Queens", "Staten Island")
pie(slices,labels=lbls,col=rainbow(length(lbls)),main="Residential Units sold in 2012")

slices <- c(c112,c212,c312,c412,c512)
lbls <- c("Manhattan", "Brooklyn", "Bronx", "Queens", "Staten Island")
pie(slices,labels=lbls,col=rainbow(length(lbls)),main="Commercial Units sold in 2012")


slices <- c(r113,r213,r313,r413,r513)
lbls <- c("Manhattan", "Brooklyn", "Bronx", "Queens", "Staten Island")
pie(slices,labels=lbls,col=rainbow(length(lbls)),main="Residential Units sold in 2013")

slices <- c(c113,c213,c313,c413,c513)
lbls <- c("Manhattan", "Brooklyn", "Bronx", "Queens", "Staten Island")
pie(slices,labels=lbls,col=rainbow(length(lbls)),main="Commercial Units sold in 2013")

