install.packages("streamR", "RCurl", "ROAuth", "RJSONIO", "twitteR")
library(streamR)
library(RCurl)
library(RJSONIO)
library(stringr)
library(twitteR)

api_key <- "QdB6dzuuoj6huoaYcmSRbjVRo" # From dev.twitter.com
api_secret <- "c4g8Ukvg1L0cM0omM6Vi7ODedG7jYGVYjqkpbd7eTMJwWzl1i0" # From dev.twitter.com
token <- "53372137-1jKE4Csq7jAPyIwGrXN9mvticdZZgnwWER9mTsims" # From dev.twitter.com
token_secret <- "TIFt5tq5zkS36ohqkuK5gB5jYHtVwF9fhbB2y3ZfgMy8j" # From dev.twitter.com

# Create Twitter Connection
setup_twitter_oauth(api_key, api_secret, token, token_secret)

tweets <- searchTwitter("'US elections 2016'", n=500, lang="en", since="2016-02-25")
tweets1 <- searchTwitter("'Presidential elections in US'", n=500, lang="en", since="2016-03-01")

# Transform tweets list into a data frame
elections.df <- twListToDF(tweets)
elections1.df <- twListToDF(tweets1)

#Bind both the dataframes together
elections.df<-rbind(elections.df, elections1.df)


#Convert to a vector to access its columns for cleaning purpose
elections<-elections.df

#perform cleaning ------
#remove Retweets RT 
elections$text = gsub("(RT|via)((?:\\b\\W*@\\w+)+)", "", elections$text)
# remove @ user/people
elections$text = gsub("@\\w+", "", elections$text)
# remove punctuation
elections$text = gsub("[[:punct:]]", "", elections$text)

# remove unnecessary spaces
elections$text = gsub("[ \t]{2,}", "", elections$text)
elections$text = gsub("^\\s+|\\s+$", "", elections$text)
# end of cleaning----


#convert vector back to df
elections.df <- elections

#remove duplicates from text fields and duplicate IDs
elections.df <- elections.df[!duplicated(elections.df[c("text")]),]
elections.df <- elections.df[!duplicated(elections.df[c("id")]),]
elections.df[!duplicated(elections.df), ]


#all cleaning done


elections<-elections.df
#remove unwanted fields
elections$favorited <- NULL
elections$replyToSID <- NULL
elections$favoriteCount <- NULL
elections$truncated<- NULL
elections$screenName <- NULL
elections$replyToSN<- NULL
elections$replyToUID <- NULL

#write to json file
json_data<-toJSON(elections)
write(json_data,file="output1.json")