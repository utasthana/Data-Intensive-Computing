shinyUI(fluidPage( 
  titlePanel("Live Streaming analysis of Tweets"), #Title
  textOutput("currentTime"),   #Here, I show a real time clock
  h4("Tweets:"),   #Sidebar title
  
  hr(),
  sidebarLayout(
    sidebarPanel(
      dataTableOutput('tweets_table') #Here I show the users and the sentiment
    ),
    
    mainPanel( 
      plotOutput("myplot1"),
      plotOutput("myplot"),
      plotOutput("distPlot"), #Here I will show the bars graph
      sidebarPanel(
        plotOutput("neutral_wordcloud") #Cloud for neutral words
      )
    ))))