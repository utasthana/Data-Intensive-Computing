install.packages("streamR", "RCurl", "ROAuth", "RJSONIO", "ggplot2", "rjson", "plotrix", "plyr", "RColorBrewer")


if (!require("pacman")) install.packages("pacman")
pacman::p_load(devtools, installr)
install.Rtools()
install_url("http://cran.r-project.org/src/contrib/Archive/Rstem/Rstem_0.4-1.tar.gz")
install_url("http://cran.r-project.org/src/contrib/Archive/sentiment/sentiment_0.2.tar.gz")
library(xtable)
library(sentiment)
library(ROAuth)
library(Rstem)
library(streamR)
library(twitteR)
library(RCurl)
library(RJSONIO)
library(stringr)
library(shiny)
library(tm)
library(wordcloud)
library(plyr)
library(Rstem)
library(ggplot2)

library(ROAuth)

shinyServer(function(input, output, session) {
  consumerKey = '7zaZdH17orzKiv2rsDVcO5nEp'
  consumerSecret = '0miviEc9JwPGagG6safRmWh4uMOOQWDM79k6LL0ni8K2XxsOH2'
  

  requestURL <- "https://api.twitter.com/oauth/request_token"
  accessURL <- "https://api.twitter.com/oauth/access_token"
  authURL <- "https://api.twitter.com/oauth/authorize"
  my_oauth = OAuthFactory$new(consumerKey = consumerKey, consumerSecret = consumerSecret,requestURL = requestURL, accessURL = accessURL, authURL = authURL)
  download.file(url="http://curl.haxx.se/ca/cacert.pem",destfile="cacert.pem")
  my_oauth$handshake(cainfo = system.file('CurlSSL', 'cacert.pem', package = 'RCurl'))
  save(my_oauth, file = 'C:/Users/UT/Downloads/my_oauth.RData') ##########please change the path
  
  load("C:/Users/UT/Downloads/my_oauth.RData")
  
  
  
  
  output$currentTime <- renderText({invalidateLater(1000, session)
    paste("Current time is: ",Sys.time())})
  observe({
    invalidateLater(60000,session)
    count_positive = 0
    count_negative = 0
    count_neutral = 0
    positive_text <- vector()
    negative_text <- vector()
    neutral_text <- vector()
    vector_users <- vector()
    vector_sentiments <- vector()
    
    tweets_result = ""
  
    ####change the query for different regions
    tweets_result = searchTwitter("'US Elections in 2016",n=1000, lang="en", since="2016-02-29")
    
    for (tweet in tweets_result){
      print(paste(tweet$screenName, ":", tweet$text))
      vector_users <- c(vector_users, as.character(tweet$screenName));
      if (grepl("elections", tweet$text, ignore.case = TRUE) == TRUE | grepl("businessman", tweet$text, ignore.case = TRUE) | grepl("politician", tweet$text, ignore.case = TRUE) | grepl("popular", tweet$text, ignore.case = TRUE) | grepl("nice", tweet$text, ignore.case = TRUE) | grepl("Awesome", tweet$text, ignore.case = TRUE)){
        count_positive = count_positive + 1
        print("positivo")
        vector_sentiments <- c(vector_sentiments, "Positive")
        positive_text <- c(positive_text, as.character(tweet$text))
      } else if (grepl("shame", tweet$text, ignore.case = TRUE) | grepl("viplent", tweet$text, ignore.case = TRUE) | grepl("racism", tweet$text, ignore.case = TRUE) | grepl("disgrace", tweet$text, ignore.case = TRUE)) { 
        count_negative = count_negative + 1
        print("negativo")
        vector_sentiments <- c(vector_sentiments, "Negative")
        negative_text <- c(negative_text, as.character(tweet$text))
      } else {
        count_neutral = count_neutral + 1
        print("neutral")
        vector_sentiments <- c(vector_sentiments, "Neutral")
        neutral_text <- c(neutral_text, as.character(neutral_text))
      }
    }
    
    
    
    df_users_sentiment <- data.frame(vector_users, vector_sentiments)
    output$tweets_table = renderDataTable({
      df_users_sentiment
    })
    
    filterStream(file = "Output1.json", # Save tweets in a json file
                 track = c("Elections in US 2016"), 
                 #change the query for each location in US
                 
                 language = "en",
                 timeout = 60, # Keep connection alive for 60 seconds
                 oauth = my_oauth) # Use my_oauth file as the OAuth credentials
    
    tweets1.df <- parseTweets("Output1.json", simplify = FALSE)
    
    while(TRUE){
      newtweets <- parseTweets("Output1.json", verbose = "FALSE")
      if(nrow(newtweets) > nrow(tweets1.df)){
        diff <- nrow(newtweets) - nrow(tweets1.df)
        seq <- 1:diff
        print(newtweets[seq,]$text)
      }
      tweets1.df <- newtweets
      Sys.sleep(2)
    }
	
	##########this plot is for tweets fetched through Search twitter which provides both the current and previous days' tweets
    
    output$myplot<-renderPlot({
      
      general.df<-twListToDF(tweets_result)
      
      general<-general.df
      
      
      general$created<-as.Date(general$created, format = "%y/%m/%d")
      general.df<-general
      #################inorder to count the number of tweets by each day, i have used the count function
      keepCount["Date"] <- NA
      keepCount<-count(general, "created")
      keepCount$Date<-keepCount$created
      keepCount$created<-NULL
      keepCount["Number_of_tweets"] <- NA
      keepCount$Number_of_tweets<-keepCount$freq
      
      ggplot(keepCount,aes(x=keepCount$Date,y=keepCount$Number_of_tweets,fill=keepCount$Date)) + geom_bar(stat = "identity")
      
    })
    #############this plot is for the live data that is streamed. i am plotting the retweet count against the date.
    output$myplot1<-renderPlot({
 
      
      tweets1<-tweets1.df
      
      tweets1$created<-as.Date(tweets1$created, format = "%y/%m/%d")
      
      tweets1.df<-tweets1
      
      ggplot(tweets1,aes(x=tweets1$created,y=tweets1$retweetCount,fill=tweets1$created)) + geom_bar(stat = "identity")
      
    })
    
    ################this is for wordcloud
    
    output$distPlot <- renderPlot({
      results = data.frame(tweets = c("Positive", "Negative", "Neutral"), numbers = c(count_positive,count_negative,count_neutral))
      barplot(results$numbers, names = results$tweets, xlab = "Sentiment", ylab = "Counts", col = c("Green","Red","Blue"))
      if (length(neutral_text) > 0){
        output$neutral_wordcloud <- renderPlot({ wordcloud(paste(neutral_text, collapse=" "), min.freq = 0, random.color=TRUE, max.words=100 ,colors=brewer.pal(8, "Dark2"))  })
      }
      
    })
  })
})