install.packages("streamR", "RCurl", "ROAuth", "RJSONIO", "ggplot2", "rjson", "plotrix", "plyr", "RColorBrewer")
library(streamR)
library(RCurl)
library(RJSONIO)
library(stringr)
library(ggplot2)
library(plotrix)
library(RColorBrewer)
library(rjson)
library(twitteR)
library(tdm)
library(Rstem)
library(wordcloud)
# Declare Twitter API Credentials
api_key <- "QdB6dzuuoj6huoaYcmSRbjVRo" # From dev.twitter.com
api_secret <- "c4g8Ukvg1L0cM0omM6Vi7ODedG7jYGVYjqkpbd7eTMJwWzl1i0" # From dev.twitter.com
token <- "53372137-1jKE4Csq7jAPyIwGrXN9mvticdZZgnwWER9mTsims" # From dev.twitter.com
token_secret <- "TIFt5tq5zkS36ohqkuK5gB5jYHtVwF9fhbB2y3ZfgMy8j" # From dev.twitter.com



# Create Twitter Connection
setup_twitter_oauth(api_key, api_secret, token, token_secret)

tweets <- searchTwitteR("'Apartments for rent in NY'", n=1000, lang="en", since="2016-01-2")
tweets1 <- searchTwitteR("'For rent in NY'", n=1000, lang="en", since="2016-01-2")

#convert list to dataframe
rentals.df<- twListToDF(tweets)
rentals1.df<- twListToDF(tweets1)

#bind 2 data frames
myrentals.df<-rbind(rentals.df, rentals1.df)

#copy to vector
myrentals<-myrentals.df


#write to file
try<-toJSON(myrentals)
write(try,file="Output4.json")

#access vector for cleaning of text field

myrentals$text = gsub("http\\w+", "", myrentals$text)
myrentals$text = gsub("(RT|via)((?:\\b\\W*@\\w+)+)", "", myrentals$text)
# remove @ user/people
myrentals$text = gsub("@\\w+", "", myrentals$text)
# remove punctuation
myrentals$text = gsub("[[:punct:]]", "", myrentals$text)

# remove unnecessary spaces
myrentals$text = gsub("[ \t]{2,}", "", myrentals$text)
myrentals$text = gsub("^\\s+|\\s+$", "", myrentals$text)



#copy back to dataframe
myrentals.df <- myrentals


#remove duplicates from text fields and duplicate IDs
myrentals.df <- myrentals.df[!duplicated(myrentals.df[c("text")]),]
myrentals.df <- myrentals.df[!duplicated(myrentals.df[c("id")]),]
myrentals.df<-myrentals.df[!duplicated(myrentals.df), ]

#sum_retweets<-sum(myrentals$retweetCount)


#starting sentiment analysis

library(twitteR)
library(wordcloud)
library(RColorBrewer)
library(plyr)
library(ggplot2)
library(sentiment)
library(Rstem)

if (!require("pacman")) install.packages("pacman")
pacman::p_load(devtools, installr)
install.Rtools()
install_url("http://cran.r-project.org/src/contrib/Archive/Rstem/Rstem_0.4-1.tar.gz")
install_url("http://cran.r-project.org/src/contrib/Archive/sentiment/sentiment_0.2.tar.gz")
library(xtable)


myrentals$text <- sapply(myrentals$text,function(row) iconv(row, "latin1", "ASCII", sub=""))

class_pol = classify_polarity(myrentals$text, algorithm="bayes")
# get polarity best fit
polarity = class_pol[,4]
# data frame with results
df_sent = data.frame(text=myrentals$text, emotion=emotion,polarity=polarity, stringsAsFactors=FALSE)
df_sent = within(df_sent,emotion <- factor(emotion, levels=names(sort(table(emotion), decreasing=TRUE))))

class_emo = classify_emotion(myrentals$text, algorithm="bayes", prior=1.0)
# get emotion best fit
emotion = class_emo[,7]
# substitute NA's by "unknown"
emotion[is.na(emotion)] = "unknown"


ggplot(df_sent, aes(x=polarity)) +geom_bar(aes(y=..count.., fill=polarity)) +scale_fill_brewer(palette="Set1") +labs(x="polarity categories", y="number of tweets") +ggtitle("Sentiment Analysis of Tweets about Rentals\n(classification by polarity)") +theme(plot.title = element_text(size=12, face="bold"))
ggplot(df_sent, aes(x=emotion)) +geom_bar(aes(y=..count.., fill=emotion)) +scale_fill_brewer(palette="Accent") +labs(x="emotion categories", y="number of tweets") +ggtitle("Sentiment Analysis of Tweets about Rentals\n(classification by emotion)") +theme(plot.title = element_text(size=12, face="bold"))


emos = levels(factor(df_sent$emotion))
nemo = length(emos)
emo.docs = rep("", nemo)
for (i in 1:nemo)
{
  tmp = myrentals$text[emotion == emos[i]]
  emo.docs[i] = paste(tmp, collapse=" ")
}


emo.docs = removeWords(emo.docs, stopwords("english"))
# create corpus
corpus = Corpus(VectorSource(emo.docs))
tdm = TermDocumentMatrix(corpus,control = list(removePunctuation = TRUE,stopwords = c("new", "year", stopwords("english")), removeNumbers = TRUE, tolower = FALSE))

tdm = as.matrix(tdm)
colnames(tdm) = emos
comparison.cloud(tdm, colors = brewer.pal(nemo, "Dark2"),scale = c(3,.5), random.order = FALSE, title.size = 1.5)




