urlpart1="http://stat.columbia.edu/~rachel/datasets/nyt"
urlpart2=".csv"
dataframe=read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt1.csv")) #put day1 data first
for(i in 2:31){
  wholeurl=paste(paste(urlpart1,i,sep=""),urlpart2,sep="") #construct the url for different days urlpart1+i+urlpart2
  subdataframe=read.csv(url(wholeurl))
  dataframe=rbind(dataframe,subdataframe) 
}

dataframe$agecat <- cut(dataframe$Age,c(-Inf,0,18,24,34,44,54,64,Inf))




#ggplot(head(age1,2),aes(x=day,y=(Clicks/Impressions),fill=day)) + geom_bar(stat = "identity")

age7_ratio<-age7$Clicks[age7$typeDay=="Weekday"]/age7$Impressions[age7$typeDay=="Weekday"]
sum_age7<-sum(age7_ratio)
rsum_age7<-signif(sum_age7, digits = 3)
age6_ratio<-age6$Clicks[age6$typeDay=="Weekday"]/age6$Impressions[age6$typeDay=="Weekday"]
sum_age6<-sum(age6_ratio)
rsum_age6<-signif(sum_age6, digits = 3)
age5_ratio<-age5$Clicks[age5$typeDay=="Weekday"]/age5$Impressions[age5$typeDay=="Weekday"]
sum_age5<-sum(age5_ratio)
rsum_age5<-signif(sum_age5, digits = 3)
age4_ratio<-age4$Clicks[age4$typeDay=="Weekday"]/age4$Impressions[age4$typeDay=="Weekday"]
sum_age4<-sum(age4_ratio)
rsum_age4<-signif(sum_age4, digits = 3)
age3_ratio<-age3$Clicks[age3$typeDay=="Weekday"]/age3$Impressions[age3$typeDay=="Weekday"]
sum_age3<-sum(age3_ratio)
rsum_age3<-signif(sum_age3, digits = 3)
age2_ratio<-age2$Clicks[age2$typeDay=="Weekday"]/age2$Impressions[age2$typeDay=="Weekday"]
sum_age2<-sum(age2_ratio)
rsum_age2<-signif(sum_age2, digits = 3)
age1_ratio<-age1$Clicks[age1$typeDay=="Weekday"]/age1$Impressions[age1$typeDay=="Weekday"]
sum_age1<-sum(age1_ratio)
rsum_age1<-signif(sum_age1, digits = 3)



ages7_ratio<-age7$Clicks[age7$typeDay=="Weekend"]/age7$Impressions[age7$typeDay=="Weekend"]
sum_ages7<-sum(ages7_ratio)
rsum_ages7<-signif(sum_ages7, digits = 3)
ages6_ratio<-age6$Clicks[age6$typeDay=="Weekend"]/age6$Impressions[age6$typeDay=="Weekend"]
sum_ages6<-sum(ages6_ratio)
rsum_ages6<-signif(sum_ages6, digits = 3)
ages5_ratio<-age5$Clicks[age5$typeDay=="Weekend"]/age5$Impressions[age5$typeDay=="Weekend"]
sum_ages5<-sum(ages5_ratio)
rsum_ages5<-signif(sum_ages5, digits = 3)
ages4_ratio<-age4$Clicks[age4$typeDay=="Weekend"]/age4$Impressions[age4$typeDay=="Weekend"]
sum_ages4<-sum(ages4_ratio)
rsum_ages4<-signif(sum_ages4, digits = 3)
ages3_ratio<-age3$Clicks[age3$typeDay=="Weekend"]/age3$Impressions[age3$typeDay=="Weekend"]
sum_ages3<-sum(ages3_ratio)
rsum_ages3<-signif(sum_ages3, digits = 3)
ages2_ratio<-age2$Clicks[age2$typeDay=="Weekend"]/age2$Impressions[age2$typeDay=="Weekend"]
sum_ages2<-sum(ages2_ratio)
rsum_ages2<-signif(sum_ages2, digits = 3)
ages1_ratio<-age1$Clicks[age1$typeDay=="Weekend"]/age1$Impressions[age1$typeDay=="Weekend"]
sum_ages1<-sum(ages1_ratio)
rsum_ages1<-signif(sum_ages1, digits = 3)

dataframe$Weekday_Activity <- ifelse(dataframe$Age >=64, rsum_age7, "NA")
dataframe$Weekday_Activity <- ifelse(dataframe$Age >=54 & dataframe$Age <64, rsum_age6, dataframe$Weekday_Activity)
dataframe$Weekday_Activity <- ifelse(dataframe$Age >=44 & dataframe$Age <54, rsum_age5, dataframe$Weekday_Activity)
dataframe$Weekday_Activity <- ifelse(dataframe$Age >=34 & dataframe$Age <44, rsum_age4, dataframe$Weekday_Activity)
dataframe$Weekday_Activity <- ifelse(dataframe$Age >=24 & dataframe$Age <34, rsum_age3, dataframe$Weekday_Activity)

dataframe$Weekday_Activity <- ifelse(dataframe$Age >=18 & dataframe$Age <24, rsum_age2, dataframe$Weekday_Activity)
dataframe$Weekday_Activity <- ifelse(dataframe$Age >=0 & dataframe$Age <18, rsum_age1, dataframe$Weekday_Activity)



dataframe["Weekend_Activity"] <- NA
dataframe$Weekend_Activity <- ifelse(dataframe$Age >=64, rsum_ages7, "NA")
dataframe$Weekend_Activity <- ifelse(dataframe$Age >=54 & dataframe$Age <64, rsum_ages6, dataframe$Weekend_Activity)
dataframe$Weekend_Activity <- ifelse(dataframe$Age >=44 & dataframe$Age <54, rsum_ages5, dataframe$Weekend_Activity)
dataframe$Weekend_Activity <- ifelse(dataframe$Age >=34 & dataframe$Age <44, rsum_ages4, dataframe$Weekend_Activity)
dataframe$Weekend_Activity <- ifelse(dataframe$Age >=24 & dataframe$Age <34, rsum_ages3, dataframe$Weekend_Activity)

dataframe$Weekend_Activity <- ifelse(dataframe$Age >=18 & dataframe$Age <24, rsum_ages2, dataframe$Weekend_Activity)
dataframe$Weekend_Activity <- ifelse(dataframe$Age >=0 & dataframe$Age <18, rsum_ages1, dataframe$Weekend_Activity)


counts <- table(dataframe$Clicks, dataframe$agecat)
barplot(counts, main="User activity by age category and days",xlab="Weekday/Weekend Activity", col=c("darkblue","red"),legend = rownames(counts), beside=TRUE)


head(dataframe,10)

d = t(matrix( c(0.211,0.611,0.079,0.231,0.08,0.23,0.079,0.230,0.08,0.231,
                0.159,0.46,0.241,0.69),
              nrow=7, ncol=2 ))
colnames(d)=c("[0,18)", "[18,24)", "[24,34)", "[34,44)", "[44,54)", "[54,64)", "[64,Inf)")

# add row of NAs for spacing
d=rbind(NA,d)


install.packages('plotrix', dependencies = TRUE)
require(plotrix)

# create barplot and store returned value in 'a'
a = gap.barplot(as.matrix(d), 
                gap=c(0.9,1.0), xlab="Age category split at 18,24,34,44,54,64",
                ytics=c(0,0.05, 0.10,0.15,0.20,0.25,0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.6),
                ylab="User activity (clicks/impressions)",xaxt='n') # disable the default x-axis

# calculate mean x-position for each group, omitting the first row 
# first row (NAs) is only there for spacing between groups
aa = matrix(a, nrow=nrow(d))
xticks = colMeans(aa[2:nrow(d),])
title(main="Bar plot for Weekday/Weekend User Activity")
text(x=12,y=0.5, labels="Dark: Weekend, Light:Weekday")
# add axis labels at mean position
axis(1, at=xticks, labels=FALSE, tick=FALSE)

data1 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt1.csv"))
head(data1)
data1$agecat <- cut(data1$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
summary(data1)
library(doBy)
siterange <- function(x){c(length(x),min(x),mean(x),max(x))}
summaryBy(Age~agecat, data=data1, FUN=siterange)
summaryBy(Gender+Signed_In+Impressions+Clicks~agecat, data=data1)
library(ggplot2)
ggplot(data1,aes(x=Impressions,file=agecat)) + geom_histogram(binwidth=1)
ggplot(data1,aes(x=agecat, y=Impressions, fill=agecat))+geom_boxplot()
data1$hasimps <- cut(data1$Impressions,c(-Inf,0,Inf))
summaryBy(Clicks~hasimps, data=data1, FUN=siterange)
ggplot(subset(data1,Impressions>0),aes(x=Clicks/Impressions,color=agecat))+geom_density()
ggplot(subset(data1,Clicks>0),aes(x=Clicks/Impressions,color=agecat))+ geom_density()
ggplot(subset(data1,Clicks>0),aes(x=agecat,y=Clicks,fill=agecat))+geom_boxplot()
ggplot(subset(data1,Clicks>0),aes(x=Clicks,color=agecat))+geom_density()
data1$scode[data1$Impressions==0] <- "NoImps"
data1$scode[data1$Impressions >0] <- "Imps"
data1$scode[data1$Clicks > 0] <- "Clicks"
data1$scode <- factor(data1$scode)
head(data1)
clen <- function(x){c(length(x))}
etable <- summaryBy(Impressions~scode+Gender+agecat,data=data1,FUN=clen)


data1 <- data1[data1$Signed_In == 1,]

mainframe <- aggregate(cbind(data1$Click,data1$Impressions)~agecat,data=data1,sum,na.rm=TRUE)
colnames(mainframe) <- c("agecat","Clicks","Impressions")
mainframe$day <- "Tuesday"
mainframe$typeDay <- "Weekday"
mainframe$date<-"May 1"

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt2.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Wednesday"
tempframe$typeDay <-  "Weekday"
tempframe$date <- "May 2"
mainframe <- rbind(mainframe,tempframe)
rm(data2)


data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt3.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Thursday"
tempframe$typeDay <-  "Weekday"
tempframe$date <- "May 3"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt4.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Friday"
tempframe$typeDay <-  "Weekday"
tempframe$date <- "May 4"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt5.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Saturday"
tempframe$typeDay <-  "Weekend"
tempframe$date <- "May 5"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt6.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Sunday"
tempframe$typeDay <-  "Weekend"
tempframe$date <- "May 6"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt7.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Monday"
tempframe$typeDay <-  "Weekday"
tempframe$date <- "May 7"
mainframe <- rbind(mainframe,tempframe)
rm(data2)


data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt8.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Tuesday"
tempframe$typeDay <-  "Weekday"
tempframe$date <- "May 8"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt9.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Wednesday"
tempframe$typeDay <-  "Weekday"
tempframe$date <- "May 9"
mainframe <- rbind(mainframe,tempframe)
rm(data2)


data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt10.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Thursday"
tempframe$typeDay <-  "Weekday"
tempframe$date <- "May 10"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt11.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Friday"
tempframe$typeDay <-  "Weekday"
tempframe$date <- "May 11"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt12.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Saturday"
tempframe$typeDay <-  "Weekend"
tempframe$date <- "May 12"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt13.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Sunday"
tempframe$typeDay <-  "Weekend"
tempframe$date <- "May 13"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt14.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Monday"
tempframe$typeDay <-  "Weekday"
tempframe$date <- "May 14"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt15.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Tuesday"
tempframe$date <- "May 15"
tempframe$typeDay <-  "Weekday"
mainframe <- rbind(mainframe,tempframe)
rm(data2)


data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt16.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Wednesday"
tempframe$typeDay <-  "Weekday"
tempframe$date <- "May 16"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt17.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Thursday"
tempframe$date <- "May 17"
tempframe$typeDay <-  "Weekday"
mainframe <- rbind(mainframe,tempframe)
rm(data2)


data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt18.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Friday"
tempframe$typeDay <-  "Weekday"
tempframe$date <- "May 18"
mainframe <- rbind(mainframe,tempframe)
rm(data2)


data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt19.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Saturday"
tempframe$date <- "May 19"
tempframe$typeDay <-  "Weekend"
mainframe <- rbind(mainframe,tempframe)
rm(data2)


data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt20.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Sunday"
tempframe$typeDay <-  "Weekend"
tempframe$date <- "May 20"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt21.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Monday"
tempframe$date <- "May 21"
tempframe$typeDay <-  "Weekday"
mainframe <- rbind(mainframe,tempframe)
rm(data2)


data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt22.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Tuesday"
tempframe$date <- "May 22"
tempframe$typeDay <-  "Weekday"
mainframe <- rbind(mainframe,tempframe)
rm(data2)


data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt23.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Wednesday"
tempframe$date <- "May 23"
tempframe$typeDay <-  "Weekday"
mainframe <- rbind(mainframe,tempframe)
rm(data2)


data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt24.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Thursday"
tempframe$date <- "May 24"
tempframe$typeDay <-  "Weekday"
mainframe <- rbind(mainframe,tempframe)
rm(data2)


data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt25.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Friday"
tempframe$date <- "May 25"
tempframe$typeDay <-  "Weekday"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt26.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Saturday"
tempframe$date <- "May 26"
tempframe$typeDay <-  "Weekend"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt27.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Sunday"
tempframe$date <- "May 27"
tempframe$typeDay <-  "Weekend"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt28.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Monday"
tempframe$date <- "May 28"
tempframe$typeDay <-  "Weekday"
mainframe <- rbind(mainframe,tempframe)
rm(data2)


data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt29.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Tuesday"
tempframe$typeDay <-  "Weekday"
tempframe$date <- "May 29"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt30.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Wednesday"
tempframe$typeDay <-  "Weekday"
tempframe$date <- "May 30"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

data2 <- read.csv(url("http://stat.columbia.edu/~rachel/datasets/nyt31.csv"))
data2$agecat <-cut(data2$Age,c(-Inf,0,18,24,34,44,54,64,Inf))
tempframe <- aggregate(cbind(data2$Click,data2$Impressions)~agecat,data=data2,sum,na.rm=TRUE)
colnames(tempframe) <- c("agecat","Clicks","Impressions")
tempframe$day <- "Thursday"
tempframe$typeDay <-  "Weekday"
tempframe$date <- "May 31"
mainframe <- rbind(mainframe,tempframe)
rm(data2)

mainframe <- mainframe[mainframe$agecat!="(-Inf,0]",]


age1 <- mainframe[mainframe$agecat=="(0,18]",]
age2 <- mainframe[mainframe$agecat=="(18,24]",]
age3 <- mainframe[mainframe$agecat=="(24,34]",]
age4 <- mainframe[mainframe$agecat=="(34,44]",]
age5 <- mainframe[mainframe$agecat=="(44,54]",]
age6 <- mainframe[mainframe$agecat=="(54,64]",]
age7 <- mainframe[mainframe$agecat=="(64, Inf]",]
library(plyr)
age1 <- arrange(age1,desc(age1$Clicks))
age2 <- arrange(age2,desc(age2$Clicks))
age3 <- arrange(age3,desc(age3$Clicks))
age4 <- arrange(age4,desc(age4$Clicks))
age5 <- arrange(age5,desc(age5$Clicks))
age6 <- arrange(age6,desc(age6$Clicks))
age7 <- arrange(age7,desc(age7$Clicks))

#ggplot(head(age1,10),aes(x=Gender,y=Clicks,fill=Gender)) + geom_bar(stat = "identity")
#dataframe[,2]<-factor(raw[,2],levels=c("Gender"),ordered=FALSE)


ggplot(head(age1,10),aes(x=day,y=Clicks,fill=day)) + geom_bar(stat = "identity")
ggplot(head(age2,10),aes(x=day,y=Clicks,fill=day)) + geom_bar(stat = "identity")
ggplot(head(age3,10),aes(x=day,y=Clicks,fill=day)) + geom_bar(stat = "identity")
ggplot(head(age4,10),aes(x=day,y=Clicks,fill=day)) + geom_bar(stat = "identity")
ggplot(head(age5,10),aes(x=day,y=Clicks,fill=day)) + geom_bar(stat = "identity")
ggplot(head(age6,10),aes(x=day,y=Clicks,fill=day)) + geom_bar(stat = "identity")
ggplot(head(age7,10),aes(x=day,y=Clicks,fill=day)) + geom_bar(stat = "identity")


age1 <- arrange(age1,desc(age1$Clicks/age1$Impressions))
age2 <- arrange(age2,desc(age2$Clicks/age2$Impressions))
age3 <- arrange(age3,desc(age3$Clicks/age3$Impressions))
age4 <- arrange(age4,desc(age4$Clicks/age4$Impressions))
age5 <- arrange(age5,desc(age5$Clicks/age5$Impressions))
age6 <- arrange(age6,desc(age6$Clicks/age6$Impressions))
age7 <- arrange(age7,desc(age7$Clicks/age7$Impressions))

ggplot(head(age1,31),aes(x=day,y=(Clicks/Impressions),fill=day)) + geom_bar(stat = "identity")
ggplot(head(age2,10),aes(x=day,y=(Clicks/Impressions),fill=day)) + geom_bar(stat = "identity")
ggplot(head(age3,10),aes(x=day,y=(Clicks/Impressions),fill=day)) + geom_bar(stat = "identity")
ggplot(head(age4,10),aes(x=day,y=(Clicks/Impressions),fill=day)) + geom_bar(stat = "identity")
ggplot(head(age5,10),aes(x=day,y=(Clicks/Impressions),fill=day)) + geom_bar(stat = "identity")
ggplot(head(age6,10),aes(x=day,y=(Clicks/Impressions),fill=day)) + geom_bar(stat = "identity")
ggplot(head(age7,10),aes(x=day,y=(Clicks/Impressions),fill=day)) + geom_bar(stat = "identity")



wkday <- mainframe[mainframe$typeDay=="Weekday",]
wknd <- mainframe[mainframe$typeDay=="Weekend",]

holiday<-mainframe[mainframe$date=="May 28",]
ggplot(holiday,aes(x=agecat,y=Clicks,fill=agecat)) + geom_bar(stat = "identity")


ggplot(wkday,aes(x=agecat,y=Clicks,fill=agecat)) + geom_bar(stat = "identity")
ggplot(wkday,aes(x=agecat,y=Impressions,fill=agecat)) + geom_bar(stat = "identity")
ggplot(wknd,aes(x=agecat,y=Clicks,fill=agecat)) + geom_bar(stat = "identity")
ggplot(wknd,aes(x=agecat,y=Impressions,fill=agecat)) + geom_bar(stat = "identity")