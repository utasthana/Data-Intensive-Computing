import java.io.IOException;
import java.util.*;
import java.io.StringReader;
import org.apache.hadoop.conf.Configuration;
import java.lang.Math;
import java.lang.Double;
//import au.com.bytecode.opencsv.CSVParser;
//import au.com.bytecode.opencsv.CSVReader;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;



/*
Authors: Akshay Kumar, Uttara Asthana
UBID:  akumar34, uttaraas

Input: bina_classshedule.csv
Output: args[1].
Temp Output: args[1]+"temp1"

objective :::: to find empty class rooms as replacements for overloaded class rooms of adequate capacity, 
in Fall 2015, for each day and time.
 */  



public class problem1 {

  
  public static class Mapper1 extends Mapper<Object, Text, Text, IntWritable>{
  private Text t1;
  private Character[] validDays= {'M', 'T', 'W', 'R', 'F', 'S'};
   
  public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
      try {
          String[] line = value.toString().split(",");  //creates array line of attributes
          int size=line.length;                         //no of attributes
          line[1] = line[1].trim();
          line[3] = line[3].trim();
          line[2] = line[2].trim();
          int capacity = Integer.parseInt(line[8]);
          String[] ar=line[2].split("\\s+");    //array with Hall and room no.
          String[] year=line[1].split("\\s+");    //array with semester and year
          int tempy=Integer.parseInt(year[1]);     //year
          boolean cleaner = capacity > 0 && size<10 && ar[0] != "Arr" && ar[1] != "Arr" && ar.length == 2 && tempy == 2015 && year[0].equals("Fall") && line[3] != "UNKWN" && line[3] != "ARR";
          if(!cleaner){return;}
          
          char[] days = line[3].toCharArray();
          int difference = capacity - Integer.parseInt(line[7]);

          if(difference < 0){                                           //if room is overloaded the requirement is calculated
            int requirement = ((-1)*difference + capacity)*(-1);
            for(char dayname:days){
              if(Arrays.asList(validDays).contains(dayname)){
                  t1 = new Text("overload"+ "," + dayname + "," + line[4] + "," + requirement + ","+line[2]+",");
                  context.write(t1, new IntWritable(1));
              }
            }

          } else if(difference == capacity) {                           //if room is empty, it is considered as a candidate for replacement
              for(char dayname:days){                                   
                if(Arrays.asList(validDays).contains(dayname)){
                  t1 = new Text("empty"+ "," + dayname + "," + line[4] + "," + capacity + "," + line[2] + ",");
                  context.write(t1, new IntWritable(1));
                }
              }                                                         //rooms which are occupied within the limit are ignored.

            }
       } 
       catch (Exception e) {}
   }
}


public static class Reducer1 extends Reducer<Text, IntWritable, Text, IntWritable> {
  private IntWritable result = new IntWritable();
  public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException { 
    context.write(key, new IntWritable(1));
    }
}

  public static class Mapper2 extends Mapper<Object, Text, Text, Text>{
    private Text t1;
    private Text t2;
   
  public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
      try {

          String[] line = value.toString().split(",");
          Double sizeCat = Double.parseDouble(line[3]);
                                                    // categorization of room requirement/capacity is done by rounding to nearest multiple of 50.
          sizeCat = Math.floor(sizeCat/50)*50;      //overloaded rooms have negative requirement. floor() will increase the absolute value.
                                                    //empty rooms have positive capacity. floor() will decrease the absolute value.
          sizeCat = Math.abs(sizeCat);              //removing the negative sign.

          int sizeCategory = sizeCat.intValue();

          t1 = new Text(line[1] + "," + line[2] + "," + sizeCategory);    //key: Day, Time, Size Category.
          if(line[0].equals("overload")){
            t2 = new Text(line[4]+"(overload)");    //rooms are tagged as overloaded or empty
            context.write(t1, t2);
          } else{
            t2 = new Text(line[4]+"(empty)");
            context.write(t1, t2);
          }
      }
        catch (Exception e) {} 
   }
  }



public static class Reducer2 extends Reducer<Text, Text, Text, Text> {
  private Text result;
  public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
      String roomList = "";
      for(Text t: values){
        roomList = roomList + t.toString()+ ", ";
      }
      result = new Text(roomList);
      context.write(key, result);                       //A list of compatible rooms are written for each key.
                                        //Key: Day, Time, SizeCategory.  Value: List of overloaded/empty rooms falling in the category
    }

}

  public static void main(String[] args) throws Exception {
    String temp1 = args[1] + "temp1";
    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, "Get overloaded and empty rooms for each day in fall 2015");
    job.setJarByClass(problem1.class);
    job.setMapperClass(Mapper1.class);
    job.setCombinerClass(Reducer1.class);
    job.setReducerClass(Reducer1.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(IntWritable.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(temp1));
    job.waitForCompletion(true);
/////////////////////////
    Configuration conf2 = new Configuration();
    Job job2 = Job.getInstance(conf2, "Categorize the rooms by requirement/capacity, and list them to suggest replacements");
    
    job2.setJarByClass(problem1.class);
    job2.setMapperClass(Mapper2.class);
    job2.setCombinerClass(Reducer2.class);
    job2.setReducerClass(Reducer2.class);
    job2.setOutputKeyClass(Text.class);
    job2.setOutputValueClass(Text.class);
    FileInputFormat.addInputPath(job2, new Path(temp1));
    FileOutputFormat.setOutputPath(job2, new Path(args[1]));
job2.waitForCompletion(true);
///////////////////////////
   
    System.exit(job2.waitForCompletion(true) ? 0 : 1);
  }
}