import java.io.IOException;
import java.util.*;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class problem4 {
    public static class Mapper1
       extends Mapper<Object, Text, Text, IntWritable>{
private Text t1;
private Text t2;
   
public void map(Object key, Text values, Context context) throws IOException, InterruptedException {
    try {
       String[] fields=values.toString().split("\\s");
       String[] nex=fields[1].split(":");
       String tm=nex[0].split("_")[0]; if(!(tm.contains("2015"))) return; //compute only for year 2015
    context.write(new Text(nex[1]+":"+nex[0]), new IntWritable(Integer.parseInt(fields[0].trim())));
   //key as Day, Year, Hall name      value: sum total of classes from previous Q3 output file

  }


      catch (Exception e) {}
 }

}
   public static class Reducer1
       extends Reducer<Text,IntWritable,Text,IntWritable> {
    private IntWritable result = new IntWritable();

    public void reduce(Text key, Iterable<IntWritable> values,
                       Context context
                       ) throws IOException, InterruptedException {
    	int sum=0;
    	for(IntWritable val:values){ //add all the values for same key
    		sum+=val.get();
    	}
    	result.set(sum);
    	context.write(key,result);
    }
  }
 


public static class Mapper2
       extends Mapper<Object, Text, IntWritable, Text>{
private Text t1;
private Text t2;
   
public void map(Object key, Text values, Context context) throws IOException, InterruptedException {
    try {

    context.write(new IntWritable(1), values);  //key as 1, valus as MR Job 1 text file
 

  }


      catch (Exception e) {}
 }

}

public static class Reducer2 extends Reducer<IntWritable, Text, IntWritable, Text> {
  private IntWritable result = new IntWritable();
  private  Text t;
 public void reduce(IntWritable key, Iterable<Text> values, 
                       Context context
                       ) throws IOException, InterruptedException {
	 

         List<String> vArrayList = new ArrayList<String>();
    

   for(Text v: values) {
       
    		vArrayList.add(v.toString());    //add each line to arraylist
              
    	} 
 String eachline;
 int size = vArrayList.size();
String f=vArrayList.get(0);
String[] sec=f.split(":"); if(sec.length<=1) return;  //to extract the day from the first line of text file

String[] third=sec[1].split("\\s");if(third.length<=1) return;
int max=Integer.parseInt(third[1].trim()); int i=0;
            for ( i=1; i<size; i++) {  //iterate through the second line onwards
               
              eachline= vArrayList.get(i);
                String[] nsec=eachline.split(":");
                if(nsec.length<=1) return;   //to prevent arrayoutofbounds exception
               String[] nthird=nsec[1].split("\\s");if(nthird.length<=1) return;
                             

  
               if(sec[0].equals(nsec[0])){   //if day is same , proceed further to calculate the hall name that has the max value for this day
               int tm=Integer.parseInt(nthird[1].trim());
               if(tm>max){ max=tm;
		third[0]=nthird[0];}
		}
//if day is diff, emit the max value and name of current day along with the associated hall that is the busiest on this day
              else{ if(sec[0].equals("R")) sec[0]="Thursday"; //give proper names to days for better reading
                       if(sec[0].equals("M")) sec[0]="Monday"; 
                             if(sec[0].equals("T")) sec[0]="Tuesday"; 
                                     if(sec[0].equals("W")) sec[0]="Wednesday"; 
                                             if(sec[0].equals("S")) sec[0]="Saturday"; if(sec[0].equals("F")) sec[0]="Friday"; 
                context.write(new IntWritable(max),new Text(sec[0]+":"+third[0]) );
                third[0]=nthird[0];
		sec[0]=nsec[0];
		max=Integer.parseInt(nthird[1].trim());
//context.write(new IntWritable(size),new Text(vArrayList.get(i)+ ""+sec[sec.length-1]));


  } //if end offile has reached, then emit current max and its corresponding hallname as the busiest hall
}  if(i==size)  {if(sec[0].equals("R")) sec[0]="Thursday"; 
                       if(sec[0].equals("M")) sec[0]="Monday"; 
                             if(sec[0].equals("T")) sec[0]="Tuesday"; 
                                     if(sec[0].equals("W")) sec[0]="Wednesday"; 
                                             if(sec[0].equals("S")) sec[0]="Saturday";  if(sec[0].equals("F")) sec[0]="Friday"; 
                                               context.write(new IntWritable(max),new Text(sec[0]+":"+third[0]) ); }


}
}
  

//public static ArrayList<String> al = new ArrayList<String>();
  public static class Mapper3
       extends Mapper<Object, Text, Text, Text>{

    private Text word = new Text();

    public void map(Object key, Text value, Context context
                    ) throws IOException, InterruptedException {
   
    	String[] fields=value.toString().split("\\s"); if(fields.length<=1) return;
        String[] tmp=fields[1].split(":"); if(tmp.length<=1) return;
    	context.write(new Text(tmp[0]),new Text(tmp[1])); //emit <DayOfTheWeek    Busiest Hall>
    }
  }

  public static class Reducer3
       extends Reducer<Text,Text,Text,Text> {
    private Text result = new Text();

    public void reduce(Text key, Iterable<Text> values,
                       Context context
                       ) throws IOException, InterruptedException {
    	int sum=0;
    	for(Text val:values){
    		result=val;
    	}
    	//result.set(sum);
    	context.write(key,result);
    }
  }




public static void main(String[] args) throws Exception {
	String temp1 = args[1] + "temp1";
    String temp2 = args[1] + "temp2";
    String temp3 = args[1] + "temp3";
       
    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, "invert the key and value from input file ");
    job.setJarByClass(problem4.class);
    job.setMapperClass(Mapper1.class);
    job.setCombinerClass(Reducer1.class);
    job.setReducerClass(Reducer1.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(IntWritable.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(temp1));
    job.waitForCompletion(true);
    Configuration conf2 = new Configuration();
    Job job2 = Job.getInstance(conf2, "calculate the halls that are busiest for each day of the week");
    job2.setJarByClass(problem4.class);
    job2.setMapperClass(Mapper2.class);
    //job2.setCombinerClass(FindIncreaseReducer.class);
    job2.setReducerClass(Reducer2.class);
    job2.setOutputKeyClass(IntWritable.class);
    job2.setOutputValueClass(Text.class);
    FileInputFormat.addInputPath(job2, new Path(temp1));
    FileOutputFormat.setOutputPath(job2, new Path(temp2));
   job2.waitForCompletion(true);
        Configuration conf3 = new Configuration();
    Job job3 = Job.getInstance(conf3, "remove the associated count and display the busiest hall name against the Day of the week");
    job3.setJarByClass(problem4.class);
    job3.setMapperClass(Mapper3.class);
 
    job3.setReducerClass(Reducer3.class);
    job3.setOutputKeyClass(Text.class);
    job3.setOutputValueClass(Text.class);
    FileInputFormat.addInputPath(job3, new Path(temp2));
    FileOutputFormat.setOutputPath(job3, new Path(args[1]));
     
    System.exit(job3.waitForCompletion(true) ? 0 : 1);
    
  }
}
