import java.io.IOException;
import java.util.*;
import java.io.StringReader;
import org.apache.hadoop.conf.Configuration;
import java.lang.Math;
import java.lang.Double;
//import au.com.bytecode.opencsv.CSVParser;
//import au.com.bytecode.opencsv.CSVReader;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;



/*
Authors: Akshay Kumar, Uttara Asthana
UBID: akumar34, uttaraas

input: bina_classschedule2.csv
output: args[1]
temp output: There are 3 temporary outputs. To access them, their names are
args[1] + "temp1", args[1] + "temp2", args[1] + "temp3"

objective: To find building capacities, and top 3 biggest buildings in terms of capacity. Based on 2015 data.
*/


public class problem2a {

  
  public static class Mapper1 extends Mapper<Object, Text, Text, IntWritable>{
  private Text room;
  private int year;
  private IntWritable capacity;
   
  public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
      try {
          String[] line = value.toString().split(",");  //creates array line of attributes
          year = Integer.parseInt(line[3].split(" ")[1]);
          if(!cleaner(line)){                       //function to filter data
            return;
          }
          room = new Text(line[5]);
          capacity = new IntWritable();
          capacity.set(Integer.parseInt(line[10]));
          context.write(room, capacity);                //emits the room name and its capacity
       } 
       catch (Exception e) {}
   }
   
   boolean cleaner(String[] line){
    if(line.length != 11) {
      return false;
    }
    if(year != 2015) {
      return false;
    }
    if(line[5].toLowerCase().contains("unknown") || line[5].toLowerCase().contains("arr")){
      return false;
    }
    if(line[5].split(" ").length != 2){
      return false;
    }
    if(Integer.parseInt(line[10]) == 0){
      return false;
    }
    return true;

   }
}


public static class Reducer1 extends Reducer<Text, IntWritable, Text, IntWritable> {
  private IntWritable capacity = new IntWritable();
  public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException { 
    Iterator<IntWritable> iterator=values.iterator();
    capacity.set(iterator.next().get());
    context.write(key, capacity);                               //writes the room name with first element from list of capacities.
                                                                //the capacity for a room in 2015 will not change. Hence one element suffices
    }
}

public static class Mapper2 extends Mapper<Object, Text, Text, IntWritable>{
  private Text building;
  private IntWritable room_capacity = new IntWritable();
   
  public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
      try {
          String[] line = value.toString().split("\\s+");  //creates array line of building, room, capacity
          building = new Text(line[0]);
          room_capacity.set(Integer.parseInt(line[2]));
          context.write(building, room_capacity);      //key : building/hall name. (Note: Room number is not emitted) Value: room capacity
       } 
       catch (Exception e) {}
   }
}

public static class Reducer2 extends Reducer<Text, IntWritable, Text, IntWritable>{
  private Text building;
  private IntWritable build_capacity = new IntWritable();

  public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
    int sum = 0;
    for(IntWritable cap: values){
      sum = sum + cap.get();                          // Summing the room capacities for all rooms in a hall.
    }
    build_capacity.set(sum);
    context.write(key, build_capacity);               //key: building name. value: total capacity of building
  }

}
/*------------------------*/
public static class Mapper3 extends Mapper<Object, Text, IntWritable, Text>{

   
  public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
      try {
          String[] line = value.toString().split("\\s+");  
          context.write(new IntWritable(Integer.parseInt(line[1])), new Text(line[0])); //for sorting. key-value flipped
       } 
       catch (Exception e) {}
   }
}


public static class Reducer3 extends Reducer<IntWritable, Text, IntWritable, Text>{

  public void reduce(IntWritable key, Text value, Context context) throws IOException, InterruptedException {
    context.write(key, value);                                          //sorting complete.
  }

}
/*-------------------------*/
public static class Mapper4 extends Mapper<Object, Text, IntWritable, Text>{

   
  public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
      try {
          context.write(new IntWritable(1), new Text(value));               //key: 1, value: full line
       } 
       catch (Exception e) {}
   }
}
public static class Reducer4 extends Reducer<IntWritable, Text, IntWritable, Text>{
  private int i = 1;
  public void reduce(IntWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
    
    Iterator<Text> iterator = values.iterator();
    while(iterator.hasNext() && i<4){
      context.write(new IntWritable(i), iterator.next());               //biggest 3 buildings are written 
      i++;
    }
  }
}


  public static void main(String[] args) throws Exception {
    String temp1 = args[1] + "temp1";
    String temp2 = args[1] + "temp2";
    String temp3 = args[1] + "temp3";
    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, "Get class capacities");
    job.setJarByClass(problem2a.class);
    job.setMapperClass(Mapper1.class);
    job.setCombinerClass(Reducer1.class);
    job.setReducerClass(Reducer1.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(IntWritable.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(temp1));
    job.waitForCompletion(true);
/////////////////////////
    Configuration conf2 = new Configuration();
    Job job2 = Job.getInstance(conf2, "Get building capacities");
    
    job2.setJarByClass(problem2a.class);
    job2.setMapperClass(Mapper2.class);
    job2.setCombinerClass(Reducer2.class);
    job2.setReducerClass(Reducer2.class);
    job2.setOutputKeyClass(Text.class);
    job2.setOutputValueClass(IntWritable.class);
    FileInputFormat.addInputPath(job2, new Path(temp1));
    FileOutputFormat.setOutputPath(job2, new Path(temp2));
    job2.waitForCompletion(true);
///////////////////////////
    Configuration conf3 = new Configuration();
    Job job3 = Job.getInstance(conf3, "Sort");
    
    job3.setJarByClass(problem2a.class);
    job3.setMapperClass(Mapper3.class);
    job3.setCombinerClass(Reducer3.class);
    job3.setReducerClass(Reducer3.class);
    job3.setOutputKeyClass(IntWritable.class);
    job3.setOutputValueClass(Text.class);
    FileInputFormat.addInputPath(job3, new Path(temp2));
    FileOutputFormat.setOutputPath(job3, new Path(temp3));
    job3.waitForCompletion(true);
//////////////////////////////
    Configuration conf4 = new Configuration();
    Job job4 = Job.getInstance(conf4, "biggest 3");
    
    job4.setJarByClass(problem2a.class);
    job4.setMapperClass(Mapper4.class);
    job4.setCombinerClass(Reducer4.class);
    job4.setReducerClass(Reducer4.class);
    job4.setOutputKeyClass(IntWritable.class);
    job4.setOutputValueClass(Text.class);
    FileInputFormat.addInputPath(job4, new Path(temp3));
    FileOutputFormat.setOutputPath(job4, new Path(args[1]));
    job4.waitForCompletion(true);
   
    System.exit(job4.waitForCompletion(true) ? 0 : 1);
  }
}