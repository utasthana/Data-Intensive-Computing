import java.io.IOException;
import java.util.*;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class problem5 {
   public static ArrayList<String> al = new ArrayList<String>();
  public static class Mapper1
       extends Mapper<Object, Text, Text, IntWritable>{

    private Text word = new Text();

    public void map(Object key, Text value, Context context
                    ) throws IOException, InterruptedException {
   
    	String[] fields=value.toString().split("\\t", -1); //read tsv file
        if(fields.length<=1) return;
        if((fields[3].contains("TERM")) )return; // if line contains this word, ignore
        if(fields[3].contains("-----------"))return;  //if line contains this word, ignore
         if((fields[12].contains("ENROLLTOTAL")))return; 
         if((fields[4].contains("SUBJECTDESCRIPTIONSOURCEKEY")))return; 
 if((fields[13].contains("COURSE")))return; // if((fields[1].contains("COURSEID")))return; 
        String[] yr=fields[3].split("\\s");
        String key1=(yr[1]+"_"+fields[4].trim());
    	word.set(key1);
         String tmp=fields[12].trim();
        int x=Integer.parseInt(tmp);
    	context.write(word,new IntWritable(x));// emit <Key as Year,Department Name and Value as enrollment count >
    }
  }

  public static class Reducer1
       extends Reducer<Text,IntWritable,Text,IntWritable> {
    private IntWritable result = new IntWritable();

    public void reduce(Text key, Iterable<IntWritable> values,
                       Context context
                       ) throws IOException, InterruptedException {
    	int sum=0;
    	for(IntWritable val:values){
    		sum+=val.get();
    	}     //add all the enrollments to various courses of the same department for each year
    	result.set(sum);
    	context.write(key,result);
    }
  }
   



public static class Mapper2
       extends Mapper<Object, Text, IntWritable, Text>{
private Text t1;
private Text t2;
   
public void map(Object key, Text values, Context context) throws IOException, InterruptedException {
    try {
// previous output file as VALUEs, key as 1 
    context.write(new IntWritable(1), values);
 

  }


      catch (Exception e) {}
 }

}

public static class Reducer2 extends Reducer<IntWritable, Text, IntWritable, Text> {
  private IntWritable result = new IntWritable();
  private  Text t;
 public void reduce(IntWritable key, Iterable<Text> values, 
                       Context context
                       ) throws IOException, InterruptedException {
	 

         List<String> vArrayList = new ArrayList<String>();
    

   for(Text v: values) {
       
    		vArrayList.add(v.toString());    //add each line of input text file to the arraylist
              
    	}
 String eachline;
 int size = vArrayList.size();
String first=vArrayList.get(0);
String[] sec=first.split("\\s");   //access Year_Dept and Value separately  (for max computation)
String[] msec=first.split("\\s");    //for min computation
String[] third=sec[0].split("_");      //access Year and department separately   (for max computation)
String[] mthird=sec[0].split("_");  //for min compute
int max=Integer.parseInt(sec[1].trim()); //store value from first line of text as max and same for min
int min=Integer.parseInt(msec[1].trim()); 
int i=0;

            for ( i=1; i<size; i++) {
               
              eachline= vArrayList.get(i);  //read next line onwards
             String[] nsec=eachline.split("\\s");
             String[] nthird=nsec[0].split("_");
             if(third[0].equals(nthird[0]))  //proceed if year is the same for the new line
{ int mx=Integer.parseInt(nsec[1].trim()); //int mn=Integer.parseInt(sec[1].trim());

if(mx>max) //compute max value

{
max=mx;
third[1]=nthird[1];

}
}

else{   //if year diff, then emit current value of max and its corresponding year and the department name. this gives most popular department
              context.write(new IntWritable(max),new Text(third[0]+":"+third[1] +"_max"));
                third[0]=nthird[0];    //update the year for next comparison
		third[1]=nthird[1];  //update the department name for next iteration
		max=Integer.parseInt(nsec[1].trim());

}


}if(i==size)  context.write(new IntWritable(max),new Text(third[0]+":"+third[1]+"_max" )); //if endoffile has reached, emit current max value and its corresponding year and most popular department name

//-------------repeat the same process for min, use diff variables

int j=0;
ArrayList<String> ar=new ArrayList<String>();
  for ( j=1; j<size; j++) {
               
              eachline= vArrayList.get(j);
             String[] nsec=eachline.split("\\s");
             String[] nthird=nsec[0].split("_");
             if(mthird[0].equals(nthird[0]))
{ //int mx=Integer.parseInt(nsec[1].trim()); 
int mn=Integer.parseInt(nsec[1].trim());

if(mn<min)

{ //ar.clear();
//ar.size()=0;
min=mn;
mthird[1]=nthird[1];
//ar.add(mthird[1]);

}
 
//if(mn==min)ar.add(mthird[1]);
    }        
else{       /*  if(ar.size()>0)
             { for(int m=0;m<ar.size();m++)  {context.write(new IntWritable(min),new Text(mthird[0]+":"+ar.get(m) +"_min"));
                  //ar.size()=0;
             mthird[0]=nthird[0];
		mthird[1]=nthird[1];
		min=Integer.parseInt(nsec[1].trim());} ar.clear();}
             
            else{  */context.write(new IntWritable(min),new Text(mthird[0]+":"+mthird[1] +"_min"));
                mthird[0]=nthird[0];
		mthird[1]=nthird[1];
		min=Integer.parseInt(nsec[1].trim());
                }

}

if(j==size) /*{ if(ar.size()>0)
             { for(int m=0;m<ar.size();m++)  {context.write(new IntWritable(min),new Text(mthird[0]+":"+ar.get(m) +"_min"));}}}
else */context.write(new IntWritable(min),new Text(mthird[0]+":"+mthird[1]+"_min" ));


}}


 //to display the least n most popular deptt for each year
  public static class Mapper3
       extends Mapper<Object, Text, Text, IntWritable>{

    private Text word = new Text();

    public void map(Object key, Text value, Context context
                    ) throws IOException, InterruptedException {
   
    	String[] fields=value.toString().split("\\s", -1); //check tlo prevent array out of bounds exception
       
    	context.write(new Text(fields[1]),new IntWritable(Integer.parseInt(fields[0].trim())));
    }
  }

  public static class Reducer3
       extends Reducer<Text,IntWritable,Text,IntWritable> {
    private IntWritable result = new IntWritable();

    public void reduce(Text key, Iterable<IntWritable> values,
                       Context context
                       ) throws IOException, InterruptedException {
    	int sum=0;
    	for(IntWritable val:values){
    		sum+=val.get();
    	}
    	result.set(sum);
    	context.write(key,result);
    }
  }
 
  public static void main(String[] args) throws Exception {
	String temp1 =args[1] + "temp1";
    String temp2 = args[1] + "temp2";
   // String temp3 = args[1] + "temp3";
    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, "get total number of registrations for every department for every year");
    job.setJarByClass(problem5.class);
    job.setMapperClass(Mapper1.class);
    job.setCombinerClass(Reducer1.class);
    job.setReducerClass(Reducer1.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(IntWritable.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(temp1));
    job.waitForCompletion(true);
    Configuration conf2 = new Configuration();
    Job job2 = Job.getInstance(conf2, "compute max and min registered departments");
    job2.setJarByClass(problem5.class);
    job2.setMapperClass(Mapper2.class);
    //job2.setCombinerClass(FindIncreaseReducer.class);
    job2.setReducerClass(Reducer2.class);
    job2.setOutputKeyClass(IntWritable.class);
    job2.setOutputValueClass(Text.class);
    FileInputFormat.addInputPath(job2, new Path(temp1));
    FileOutputFormat.setOutputPath(job2, new Path(temp2));
    job2.waitForCompletion(true);
        Configuration conf3 = new Configuration();
    Job job3 = Job.getInstance(conf3, "display for every year, the most and least popular departments");
    job3.setJarByClass(problem5.class);
    job3.setMapperClass(Mapper3.class);
    //job2.setCombinerClass(FindIncreaseReducer.class);
    job3.setReducerClass(Reducer3.class);
    job3.setOutputKeyClass(Text.class);
    job3.setOutputValueClass(IntWritable.class);
    FileInputFormat.addInputPath(job3, new Path(temp2));
    FileOutputFormat.setOutputPath(job3, new Path(args[1]));
    System.exit(job3.waitForCompletion(true) ? 0 : 1);
    
  }
}
