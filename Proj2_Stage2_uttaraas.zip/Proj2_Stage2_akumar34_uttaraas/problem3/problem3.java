import java.io.IOException;
import java.util.*;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class problem3 {
   public static ArrayList<String> al = new ArrayList<String>();
  public static class Mapper1
       extends Mapper<Object, Text, Text, IntWritable>{

    private Text t1;
      private String[] validDays= {"M", "T", "W", "R", "F", "S"};
    public void map(Object key, Text value, Context context
                    ) throws IOException, InterruptedException {
   
    	  try {
       String[] line = value.toString().split(",");
     int size=line.length;
 String hall_name;

if(line[5].contains("")){   //to check if hall name contains space because if no space, then it is most likely to be 'Unknown'
  String[] ar=line[5].split("\\s+");
  String[] year=line[3].split("\\s+");  
  int temp=Integer.parseInt(year[1]);    //filter the year
//------------data cleaning below
   if((!ar[0].equalsIgnoreCase("Arr"))&&(!ar[0].equalsIgnoreCase("Unknown"))&&(!line[7].equalsIgnoreCase("Before 8:00AM"))&&(!line[7].equalsIgnoreCase("Unknown"))&&(size<12)) { //do not enter loop if enrollment column has String variables from th previous column
  if(Integer.parseInt(line[9])>0){    //if enrollment is 0 or less do not enter loop
  for(int i=0;i<validDays.length;i++) {
    if(line[6].contains(validDays[i])){
  IntWritable maxcap= new IntWritable(1);   

    t1=new Text(year[1]+"_"+ar[0]+"="+validDays[i]+"=");  //take key as Year , hall name and Day of the week

   context.write(t1,new IntWritable(1)); //value as 1

}
 }}    
}}} catch (Exception e) {}

    }
  }

  public static class Reducer1
       extends Reducer<Text,IntWritable,Text,IntWritable> {
    private IntWritable result = new IntWritable();

    public void reduce(Text key, Iterable<IntWritable> values,
                       Context context
                       ) throws IOException, InterruptedException {
    	int sum=0;
    	for(IntWritable val:values){
    		sum+=val.get();
    	}
    	result.set(sum);
    	context.write(key,result);
    }
  }
 public static class Mapper2
       extends Mapper<Object, Text, IntWritable, Text>{
private Text t1;
private Text t2;
   
public void map(Object key, Text values, Context context) throws IOException, InterruptedException {
    try {   //read the previous output file and take into values

    context.write(new IntWritable(1), values);
 //key is 1, values is Text file

  }


      catch (Exception e) {}
 }

}

public static class Reducer2 extends Reducer<IntWritable, Text, IntWritable, Text> {
  private IntWritable result = new IntWritable();
  private  Text t;
 public void reduce(IntWritable key, Iterable<Text> values, 
                       Context context
                       ) throws IOException, InterruptedException {
	 

         List<String> vArrayList = new ArrayList<String>();
    

   for(Text v: values) {
       
    		vArrayList.add(v.toString());     //take each line into an arraylist index
              
    	}
 String eachline;
 int size = vArrayList.size();
String t1=vArrayList.get(0);
String[] st1=t1.split("=");     //extract the hall name from first line 
int max=Integer.parseInt(st1[2].trim()); int i=0;    //consider the initial value as max
            for ( i=1; i<size; i++) {    //read from the second line
               
              eachline= vArrayList.get(i);
                String[] split1=eachline.split("=");
                if(split1.length<=1) return;
                if(st1[0].equals(split1[0])){     //proceed if hall name is name
               int tm=Integer.parseInt(split1[2].trim());
               if(tm>max){ max=tm;   //calculate the max value to know the day with max number of classes in a hall
		st1[1]=split1[1];}
		}
              else{    //if hall name is diff, emit the max value and corresponding hall name with year
                context.write(new IntWritable(max),new Text(st1[0]+":"+st1[1]) );
                st1[0]=split1[0];     //update with new hall name
		st1[1]=split1[1];
		max=Integer.parseInt(split1[2].trim());  //update the max variable


}
if (i==size) context.write(new IntWritable(max),new Text(st1[0]+":"+st1[1]) ); //if endoffile is reached, emit the current max and hallnames
}               
             


}
}
  

       


 


public static void main(String[] args) throws Exception {
	String temp1 = args[1] + "temp1";

    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, "get total number of classes held in each hall for every year (for all the classrooms in a hall)");
    job.setJarByClass(problem3.class);
    job.setMapperClass(Mapper1.class);
    job.setCombinerClass(Reducer1.class);
    job.setReducerClass(Reducer1.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(IntWritable.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(temp1));
    job.waitForCompletion(true);
    Configuration conf2 = new Configuration();
    Job job2 = Job.getInstance(conf2, "calculate the peak day for every hall for all years");
    job2.setJarByClass(problem3.class);
    job2.setMapperClass(Mapper2.class);
    //job2.setCombinerClass(FindIncreaseReducer.class);
    job2.setReducerClass(Reducer2.class);
    job2.setOutputKeyClass(IntWritable.class);
    job2.setOutputValueClass(Text.class);
    FileInputFormat.addInputPath(job2, new Path(temp1));
    FileOutputFormat.setOutputPath(job2, new Path(args[1]));
 
    System.exit(job2.waitForCompletion(true) ? 0 : 1);
    
  }
}
