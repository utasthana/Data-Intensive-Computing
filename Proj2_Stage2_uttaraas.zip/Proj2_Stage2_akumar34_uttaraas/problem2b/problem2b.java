import java.io.IOException;
import java.util.*;
import java.io.StringReader;
import org.apache.hadoop.conf.Configuration;
import java.lang.Math;
import java.lang.Double;
//import au.com.bytecode.opencsv.CSVParser;
//import au.com.bytecode.opencsv.CSVReader;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;



/*
Authors: Akshay Kumar, Uttara Asthana
UBID: akumar34, uttaraas
C
input: bina_classschedule.csv
output: args[1].
temp output is generated at args[1]+"temp1".
to view temp output, access directory args[1]+"temp1".

objective:ONLY FOR HALL: NSC - Extended from a previous question which finds biggest halls(buildings):
            MR1: Year - Day - %occupancy.
            MR2: Yearwise change in %occupancy for each day.

*/

public class problem2b {

  
  public static class Mapper1 extends Mapper<Object, Text, Text, Text>{
    private Text yearday;
    private Text occu_cap;
    private int year;
    private Character[] validDays= {'M', 'T', 'W', 'R', 'F', 'S'};

  public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
      try {
          String[] line = value.toString().split(",");  //creates array line of attributes
          year = Integer.parseInt(line[1].split(" ")[1]); // year

          if(!cleaner(line)){             //removes unwanted entries
            return;
          }

          String hall = line[2].split(" ")[0];            //hall name 
          int cap = Integer.parseInt(line[8].trim());     //room capacity
          int occu = Integer.parseInt(line[7].trim());    //room occupancy 
          char[] days = line[3].toCharArray();

          for(char dayname:days){                                   //for each day in schedule
                if(Arrays.asList(validDays).contains(dayname)){
                  yearday = new Text(year + "_" + dayname);       //year_Nsc
                  occu_cap = new Text(occu + "_" + cap);          //occupancy_capacity
                  context.write(yearday, occu_cap);               //emit for each day in its schedule.
                }
              }


          
       } 
       catch (Exception e) {}
   }
   
   boolean cleaner(String[] line){        //function to clean and remove unwanted data.
    if(line.length != 9) {
      return false;
    }
    if(line[2].split(" ").length != 2){
      return false;
    }
    if(line[3].toLowerCase().contains("unknown") || line[3].toLowerCase().contains("arr")){
      return false;
    }
    
    if(line[2].toLowerCase().contains("arr")){
      return false;
    }
    if(year > 2015 || year < 1994){
      return false;
    }
    if(Integer.parseInt(line[8]) < 1){
      return false;
    }
    if(Integer.parseInt(line[7]) < 1){
      return false;
    }

    if(line[2].toLowerCase().contains("nsc")){   //filter for nsc
      return true;
    }
    return false;

   }
}


public static class Reducer1 extends Reducer<Text, Text, Text, Text> {
 // private Text result;
  public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException { 
    
    int sum_occu = 0;
    int sum_cap = 0;
    Iterator<Text> iter = values.iterator();
    
    if(!iter.hasNext()){return;}
    
    for(Text val:values){                               //occupancy_capacity
      
      String[] s = val.toString().split("_");
      sum_occu += Integer.parseInt(s[0]);               //summing occupancy
      sum_cap += Integer.parseInt(s[1]);                //summing capacity
    }

    int percent = (sum_occu*100)/sum_cap;               //percentage occupancy
    String result = Integer.toString(percent);
    
    context.write(key, new Text(result));
    }
}


public static class Mapper2 extends Mapper<Object, Text, Text, IntWritable>{
  private Text t1;
  private Text t2;
  private IntWritable percentage;
   
  public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
      try {
        String[] line = value.toString().split("\\s+");
        String day = line[0].split("_")[1];
        int year = Integer.parseInt(line[0].split("_")[0]);
        
        //if(!day.equals("W")){return;}                       if single day analysis is required, uncomment this line.
        
        percentage = new IntWritable(Integer.parseInt(line[1]));
        t1 = new Text(year + "-" + (year+1) + "_" + day);
        t2 = new Text((year-1) + "-" + year + "_" + day);
        context.write(t1, percentage);
        context.write(t2, percentage);
       } 

       catch (Exception e) {}
   }
}

public static class Reducer2 extends Reducer<Text, IntWritable, Text, IntWritable> {
  private IntWritable result = new IntWritable();
  public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException { 
    int diff = 0;

    Iterator<IntWritable> iter = values.iterator();

    int count1 = iter.next().get();

    if(!iter.hasNext()){return;}

    int count2 = iter.next().get();

    diff = count2 - count1;                         //difference in percentages of 2 consecutive years.

    result.set(diff);
    context.write(key, result);

    }
}

  public static void main(String[] args) throws Exception {
    String temp1 = args[1] + "temp1"; 

    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, "Calculate percentage occupancy for each day for each year for NSC.");
    job.setJarByClass(problem2b.class);
    job.setMapperClass(Mapper1.class);

    job.setReducerClass(Reducer1.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(Text.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(temp1));
    job.waitForCompletion(true);


    Configuration conf2 = new Configuration();
    Job job2 = Job.getInstance(conf2, "Get change in occupancy for NSC over the years, for each day.");
    
    
    job2.setJarByClass(problem2b.class);
    job2.setMapperClass(Mapper2.class);

    job2.setReducerClass(Reducer2.class);
    job2.setOutputKeyClass(Text.class);
    job2.setOutputValueClass(IntWritable.class);
    FileInputFormat.addInputPath(job2, new Path(temp1));
    FileOutputFormat.setOutputPath(job2, new Path(args[1]));
    job2.waitForCompletion(true);
   
    System.exit(job2.waitForCompletion(true) ? 0 : 1);
  }
}
